# 协作者数据库访问包

此包包含访问 LoopcruiseTheatre 数据库所需的所有文件。

## 🚀 快速开始

1. **安装环境**
   ```bash
   python collaborator_setup.py
   ```

2. **启动服务**
   ```bash
   python start_database_api.py
   ```

3. **访问API**
   - 服务地址: http://localhost:8001
   - API文档: http://localhost:8001/docs

## 📁 文件说明

- `collaborator_setup.py` - 环境安装脚本
- `database_only_main.py` - 数据库API服务
- `database_export.py` - 数据导入导出工具
- `database_only_requirements.txt` - 精简依赖列表
- `app/` - 核心应用代码
- `database_exports/` - 共享的数据库文件

## 📊 数据访问

导入数据库文件：
```bash
python database_export.py --action import --input database_exports/conversations_shared_*.db
```

查看完整指南：参考项目根目录的 `COLLABORATOR_GUIDE.md`

---
生成时间: 2025-10-15 17:03:23
